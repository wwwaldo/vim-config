abc = "E121", (
    #: E121:2
  "dent")
abc = "E122", (
    #: E121:0
"dent")
my_list = [
    1, 2, 3,
    4, 5, 6,
    #: E123
    ]
abc = "E124", ("visual",
               "indent_two"
               #: E124:14
              )
abc = "E124", ("visual",
               "indent_five"
               #: E124:0
)
a = (123,
     #: E124:0
)
#: E129+1:4
if (row < 0 or self.moduleCount <= row or
    col < 0 or self.moduleCount <= col):
    raise Exception("%s,%s - %s" % (row, col, self.moduleCount))

abc = "E126", (
    #: E126:12
            "dent")
abc = "E126", (
    #: E126:8
        "dent")
abc = "E127", ("over-",
               #: E127:18
                  "over-indent")
abc = "E128", ("visual",
               #: E128:4
    "hanging")
abc = "E128", ("under-",
               #: E128:14
              "under-indent")


my_list = [
    1, 2, 3,
    4, 5, 6,
    #: E123:5
     ]
result = {
    #: E121:3
   'key1': 'value',
    #: E121:3
   'key2': 'value',
}
rv.update(dict.fromkeys((
              'qualif_nr', 'reasonComment_en', 'reasonComment_fr',
              'reasonComment_de', 'reasonComment_it'),
                        #: E128:10
          '?'),
          "foo")

abricot = 3 + \
          4 + \
          5 + 6
abc = "hello", (

    "there",
    #: E126:5
     # "john",
    "dude")
part = set_mimetype((
    a.get('mime_type', 'text')),
                    'default')
part = set_mimetype((
    a.get('mime_type', 'text')),
                    #: E127:21
                     'default')
