.. include:: ../global.rst

.. _api-classes:

API Return Classes
------------------

.. automodule:: jedi.api.classes
    :members:
    :undoc-members:
