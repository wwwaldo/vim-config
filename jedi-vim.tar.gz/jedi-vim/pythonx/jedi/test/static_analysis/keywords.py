def raises():
    raise KeyError()


def wrong_name():
    #! 6 name-error
    raise NotExistingException()
