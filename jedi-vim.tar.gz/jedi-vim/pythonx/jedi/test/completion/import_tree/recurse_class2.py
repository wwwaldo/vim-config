from . import recurse_class1

class C(recurse_class1.C):
    pass
